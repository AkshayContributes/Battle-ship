package entity;

import java.util.HashSet;
import java.util.List;

public class FleetItem {

  private final String name;
  private final IBoundary boundary;

  public FleetItem(String name, IBoundary boundary) {
    this.name = name;
    this.boundary = boundary;
  }

  public boolean isKilled(HashSet<Coordinate> bombedLocations) {
    final List<Coordinate> itemCoordinates = boundary.allCoordinates();
    for(Coordinate itemCoordinate: itemCoordinates){
      if(bombedLocations.contains(itemCoordinate)) return true;
    }
    return false;
  }

  public boolean containsCoordinate(Coordinate coordinate) {
    return this.boundary.contains(coordinate);
  }

}
