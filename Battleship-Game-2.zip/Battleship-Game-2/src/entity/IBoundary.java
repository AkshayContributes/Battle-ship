package entity;

import java.util.List;

public interface IBoundary {
  boolean contains(Coordinate coordinate);

  List<Coordinate> allCoordinates();
}
