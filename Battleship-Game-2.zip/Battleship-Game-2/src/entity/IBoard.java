package entity;

public interface IBoard {
  public boolean areAllShipsKilled();

  public void takeHit(Coordinate coordinate);


}
