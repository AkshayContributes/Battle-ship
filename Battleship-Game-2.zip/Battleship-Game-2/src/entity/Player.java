package entity;

import strategy.IChanceStrategy;

import java.util.ArrayList;
import java.util.List;

public class Player {

  private final Board board;
  private final Integer id;
  private final IChanceStrategy chanceStrategy;

  public Player(Board board, Integer id, IChanceStrategy chanceStrategy) {
    this.board = board;
    this.id = id;
    this.chanceStrategy = chanceStrategy;
  }

  public Coordinate takeChance(){
    return chanceStrategy.getPlayerChanceTarget(this);
  }

  public boolean areAllShipsKilled(){
    return board.areAllShipsKilled();
  }

  public void takeHit(Coordinate coordinate){
    board.takeHit(coordinate);
  }

  public Board getBoard() {
    return board;
  }

  public Integer getId() {
    return id;
  }

  public IChanceStrategy getChanceStrategy() {
    return chanceStrategy;
  }
}
