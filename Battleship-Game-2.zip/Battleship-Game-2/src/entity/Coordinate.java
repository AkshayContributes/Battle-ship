package entity;


public class Coordinate {

  private final Integer xCoordinate;
  private final Integer yCoordinate;

  public Coordinate(Integer xCoordinate, Integer yCoordinate){
    this.xCoordinate = xCoordinate;
    this.yCoordinate = yCoordinate;
  }

  public Integer getxCoordinate() {
    return xCoordinate;
  }

  public Integer getyCoordinate() {
    return yCoordinate;
  }



}
