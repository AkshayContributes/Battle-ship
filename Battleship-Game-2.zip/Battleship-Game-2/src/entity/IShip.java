package entity;

public interface IShip {

}
