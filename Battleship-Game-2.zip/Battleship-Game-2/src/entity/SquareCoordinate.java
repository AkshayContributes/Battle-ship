package entity;

import java.util.ArrayList;
import java.util.List;

public class SquareCoordinate implements IBoundary {
  private final Coordinate topLeft;
  private final Coordinate bottomRight;


  public SquareCoordinate(Coordinate topLeft, Coordinate bottomRight) {
    this.topLeft = topLeft;
    this.bottomRight = bottomRight;
  }

  public List<Coordinate> allCoordinates(){
    List<Coordinate> coordinates = new ArrayList<>();
    for(int i = topLeft.getxCoordinate(); i<= bottomRight.getxCoordinate(); i++){
      for(int j = topLeft.getyCoordinate(); j <= bottomRight.getyCoordinate(); j++){
        coordinates.add(new Coordinate(i, j));
      }
    }

    return coordinates;
  }

  public boolean contains(final Coordinate coordinate){
    return coordinate.getxCoordinate() >= topLeft.getxCoordinate() && coordinate.getyCoordinate() <= bottomRight.getxCoordinate()
            && coordinate.getyCoordinate() >= topLeft.getyCoordinate() && coordinate.getyCoordinate() <= bottomRight.getyCoordinate();
  }

  public Coordinate getTopLeft() {
    return topLeft;
  }

  public Coordinate getBottomRight() {
    return bottomRight;
  }
}
