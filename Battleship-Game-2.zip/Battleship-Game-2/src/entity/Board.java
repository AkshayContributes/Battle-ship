package entity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class Board implements IBoard{
  private List<FleetItem> ships;
  private final IBoundary boundary;
  private final HashSet<Coordinate> allBombLocations;

  public Board(final List<FleetItem> ships, final IBoundary boundary){
    this.boundary = boundary;
    this.allBombLocations = new HashSet<>();
  }

  public void addShip(String itemName, Coordinate coordinate, Integer size){
    if(size % 2 != 0) throw new RuntimeException();
    int minX = coordinate.getxCoordinate() - size/2;
    int minY = coordinate.getyCoordinate() - size/2;
    int maxX = coordinate.getxCoordinate() + size/2;
    int maxY = coordinate.getyCoordinate() + size/2;

    for(int i = minX; i<=maxX; i++){
      for(int j= minY; j<=maxY; j++){
        if(!isValid(i, j)){
          throw new RuntimeException();
        }
      }
    }

    IBoundary shipBoundary = new SquareCoordinate(new Coordinate(minX, minY) , new Coordinate(maxX, maxY));

    ships.add(new FleetItem(itemName, shipBoundary));
  }

  public void takeHit(final Coordinate coordinate){
    if(!boundary.contains(coordinate)){
        throw new RuntimeException();
    }

    allBombLocations.add(coordinate);
  }

  public boolean areAllShipsKilled() {
    for(FleetItem ship: ships){
      if(!ship.isKilled(allBombLocations)){
        return false;
      }
    }

    return true;
  }

  public List<Coordinate> hitLocations(){
    final List<Coordinate> hits = new ArrayList<>();
    for(Coordinate coordinate: allBombLocations){
      for(FleetItem ship: ships){
        if(ship.containsCoordinate(coordinate)){
          hits.add(coordinate);
          break;
        }
      }
    }

    return hits;
  }

  public Board(List<FleetItem> ships, IBoundary boundary, HashSet<Coordinate> allBombLocations) {
    this.ships = ships;
    this.boundary = boundary;
    this.allBombLocations = allBombLocations;
  }

  public List<FleetItem> getShips() {
    return ships;
  }

  public IBoundary getBoundary() {
    return boundary;
  }

  public HashSet<Coordinate> getAllBombLocations() {
    return allBombLocations;
  }

  private boolean isValid(int x, int y){
    if(boundary.contains(new Coordinate(x, y))){
      for(FleetItem fleetItem: ships){
        if(fleetItem.containsCoordinate(new Coordinate(x, y))) return false;
      }
    }else{
      return false;
    }

    return true;
  }
}
