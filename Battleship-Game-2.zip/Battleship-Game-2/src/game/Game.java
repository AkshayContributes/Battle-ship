package game;

import entity.Coordinate;
import entity.Player;
import strategy.ITurnStrategy;
import strategy.IWinningStrategy;

import java.util.List;

public class Game {
  private final List<Player> players;
  private final IWinningStrategy winningStrategy;
  private final ITurnStrategy turnStrategy;

  public Game(List<Player> players, IWinningStrategy winningStrategy, ITurnStrategy turnStrategy) {
    this.players = players;
    this.winningStrategy = winningStrategy;
    this.turnStrategy = turnStrategy;
  }

  public void start(){
    int currentPlayerIndex = turnStrategy.firstPlayer(this.players);
    System.out.println("Starting game");
    while(true){
      final Player currentPlayer = players.get(currentPlayerIndex);
      System.out.println(String.format("Player %s turn ", currentPlayer.getId()));
      final Coordinate target = currentPlayer.takeChance();
      for(Player player: this.players){
          if(player.getId() != currentPlayer.getId()){
            player.takeHit(target);
          }
      }

      final Player winner = winningStrategy.getWinner(players);
      if(winner != null){
        System.out.println(winner.getId()+" has won the game");
      }

      currentPlayerIndex = turnStrategy.pickNextPlayer(currentPlayerIndex, players);

    }


  }
}
