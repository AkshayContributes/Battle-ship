package input;

import entity.Coordinate;
import entity.Player;

import java.util.Random;

public class RandomTargetGenerator implements TargetGenerator {

  @Override public Coordinate generateTarget(Player player) {
    Random random = new Random();
    Integer randomIndex = random.nextInt(player.getBoard().getBoundary().allCoordinates().size());
    return player.getBoard().getBoundary().allCoordinates().get(randomIndex);
  }
}
