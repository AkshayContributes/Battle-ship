package input;

import entity.Coordinate;
import entity.Player;

public interface TargetGenerator {

  public Coordinate generateTarget(Player player);

}
