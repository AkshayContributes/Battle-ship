package strategy;

import entity.Player;

import java.util.List;

public class TwoPersonTurn implements ITurnStrategy{

  @Override public Integer firstPlayer(List<Player> players) {
    if(players.size() == 0) throw new RuntimeException();

    return 0;
  }

  @Override public Integer pickNextPlayer(Integer currentPlayerIndex, List<Player> players) {
    if(players.size() < 2) throw new RuntimeException();
    return currentPlayerIndex == 0 ? 1 : 0;
  }
}
