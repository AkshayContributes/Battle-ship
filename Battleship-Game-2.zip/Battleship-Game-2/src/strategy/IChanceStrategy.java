package strategy;

import entity.Coordinate;
import entity.Player;
import entity.PlayerChanceTarget;

import java.util.List;

public interface IChanceStrategy {

  Coordinate getPlayerChanceTarget(Player player);
}
