package strategy;

import entity.Player;

import java.util.List;

public interface ITurnStrategy {
  Integer firstPlayer(List<Player> players);
  Integer pickNextPlayer(Integer currentPlayerIndex, List<Player> players);

}
