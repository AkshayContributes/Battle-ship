package strategy;

import entity.Player;

import java.util.List;

public interface IWinningStrategy {

  public Player getWinner(List<Player> players) ;
}
