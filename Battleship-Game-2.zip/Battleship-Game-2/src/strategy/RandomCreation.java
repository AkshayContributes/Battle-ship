package strategy;

import entity.Coordinate;
import entity.Player;
import entity.PlayerChanceTarget;
import input.TargetGenerator;
import input.RandomTargetGenerator;

import java.util.List;

public class RandomCreation implements IChanceStrategy{

  private final TargetGenerator targetGenerator;

  public RandomCreation(TargetGenerator targetGenerator) {
    this.targetGenerator = targetGenerator;
  }

  @Override
  public Coordinate getPlayerChanceTarget(Player player) {
     return targetGenerator.generateTarget(player);
  }
}
