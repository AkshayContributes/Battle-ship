package strategy;

import entity.Player;

import java.util.ArrayList;
import java.util.List;

public class DefaultWinningStrategy implements IWinningStrategy{

  @Override
  public Player getWinner(final List<Player> playerList) {
    final List<Player> alivePlayers = new ArrayList<>();
    for (Player player : playerList) {
      if (!player.areAllShipsKilled()) {
        alivePlayers.add(player);
      }
    }
    if (alivePlayers.size() == 1) {
      return alivePlayers.get(0);
    }
    return null;
  }
}
